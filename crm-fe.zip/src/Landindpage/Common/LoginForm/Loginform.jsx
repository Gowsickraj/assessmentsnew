import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import './Loginform.css';

const UserForm = () => {
  const navigate = useNavigate();
  
  const [isLogin, setIsLogin] = useState(true);

  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!isLogin) {
      if (formData.password !== formData.confirmPassword) {
        alert("Passwords do not match!");
        return;
      }
      console.log("Registration Form submitted", formData);
    } else {
     
      console.log("Login Form submitted", {
        email: formData.email,
        password: formData.password
      });
    }
  };

  const handleCancel = () => {
    setFormData({
      username: '',
      email: '',
      password: '',
      confirmPassword: ''
    });
    navigate('/');
  };

  const toggleMode = () => {
    setIsLogin(!isLogin);
  };

  return (
    <div className="user-form-container">
      <h2>{isLogin ? "Login" : "Register"}</h2>
      <form onSubmit={handleSubmit}>
        {!isLogin && (
          <div>
            <label htmlFor="username">Username:</label>
            <input
              type="text"
              name="username"
              value={formData.username}
              onChange={handleChange}
              required={!isLogin}
            />
          </div>
        )}
        <div>
          <label htmlFor="email">Email ID:</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
          />
        </div>
        {!isLogin && (
          <div>
            <label htmlFor="confirmPassword">Confirm Password:</label>
            <input
              type="password"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              required={!isLogin}
            />
          </div>
        )}
        <div className="form-actions">
          <button type="submit">{isLogin ? "Login" : "Register"}</button>
          <button type="button" onClick={handleCancel}>Cancel</button>
        </div>
      </form>
      <p>
        {isLogin ? "Don't have an account?" : "Already registered?"}{" "}
        <button type="button" onClick={toggleMode}>
          {isLogin ? "Register" : "Login"}
        </button>
      </p>
    </div>
  );
};

export default UserForm;
