import React from "react";
import "./Dashboard.css";
import Barchart from "./Charts/Barchart";
import { DoughnutChart } from "./Charts/Doughnutchart";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCommentSms,
  faGaugeHigh,
  faPhone,
  faUser,
} from "@fortawesome/free-solid-svg-icons";

export const Dashboard = () => {
  return (
    <div>
      <h2 className="dashboard_crm_charts_h2">
        <FontAwesomeIcon
          style={{ color: "green", fontSize: "25px" }}
          icon={faGaugeHigh}
        />{" "}
        Dashboard
      </h2>
      <div className="dashboard_crm_charts">
        <div className="chart_crm">
          <h3 style={{ marginTop: "10px", fontSize: "25px" }}>
            <FontAwesomeIcon
              style={{
                color: "yellow",
                fontSize: "15px",
                boxShadow: "1px 1px 4px 1px #867f7f",
                padding: "3px",
                borderRadius: "5px",
              }}
              icon={faUser}
            />{" "}
            Total users
          </h3>
          <hr
            style={{
              width: "200px",
              marginLeft: "130px",
              fontWeight: "900",
              marginTop: "10px",
            }}
          />
          <Barchart />
        </div>
        <div className="chart_crm">
          <h3 style={{ marginTop: "10px", fontSize: "23px" }}>
            <FontAwesomeIcon
              style={{
                color: "green",
                fontSize: "15px",
                boxShadow: "1px 1px 4px 1px #867f7f",
                padding: "4px",
                borderRadius: "5px",
              }}
              icon={faPhone}
            />{" "}
            Total Voice &{" "}
            <FontAwesomeIcon
              style={{
                fontSize: "17px",
                color: "blue",
                borderRadius: "5px",
                boxShadow: "1px 1px 4px 1px #867f7f",
                padding: "4px",
              }}
              icon={faCommentSms}
            />{" "}
            SMS logs
          </h3>
          <hr
            style={{
              width: "320px",
              marginLeft: "60px",
              fontWeight: "500",
              marginTop: "10px",
            }}
          />

          <DoughnutChart />
        </div>
      </div>
    </div>
  );
};
