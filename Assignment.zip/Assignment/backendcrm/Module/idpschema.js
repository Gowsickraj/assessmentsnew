const { mongoose } = require("mongoose");

const TokenSchema = new mongoose.Schema({
  hash: {
    type: String,
    required: true,
  },
  access_token: {
    type: String,
    required: true,
  },
  refresh_token: {
    type: String,
    required: true,
  },
  expireTime: {
    type: Date,
    required: true,
  },
  jwt: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
    expires: '3h', 
  },
});

const TokenModel = mongoose.model("Token", TokenSchema);

module.exports = TokenModel;