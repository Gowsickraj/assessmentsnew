const SMS = require("../Module/sms");

const Savesms = async (req, res) => {
  try {
    const { adminNumber, customerNumber, content } = req.body;

    // Validate input
    if (!/^[6-7-8-9]\d{9}$/.test(adminNumber)) {
      return res.status(400).json({ error: "Invalid admin number format." });
    }
    if (!/^[6-7-8-9]\d{9}$/.test(customerNumber)) {
      return res.status(400).json({ error: "Invalid customer number format." });
    }
    if (!content || content.length > 160) {
      return res
        .status(400)
        .json({
          error: "Invalid SMS content. It must be less than 160 characters.",
        });
    }

    // Create and save SMS
    const sms = new SMS({ adminNumber, customerNumber, content });
    await sms.save();

    res.status(201).json({ message: "SMS saved successfully", sms });
  } catch (error) {
    console.error("Error saving SMS:", error);
    res.status(500).json({ error: "Internal server error while saving SMS." });
  }
};
module.exports = Savesms;
