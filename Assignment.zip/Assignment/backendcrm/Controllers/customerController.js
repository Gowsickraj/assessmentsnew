const Customer = require("../Module/Customer");

// Controller add new customer
const addCustomer = async (req, res) => {
    const { name, contactNumber, email, whatsappNumber } = req.body;

    try {
        // Validate required fields are provided and not empty
        if (!name || !contactNumber || !email) {
            return res.status(400).json({ msg: "Name, Contact Number, and Email are required.", code: 400 });
        }

        // Check if contactNumber is empty or does not meet the pattern
        if (!contactNumber || !/^[6-7-8-9]\d{9}$/.test(contactNumber)) {
            return res.status(400).json({ msg: "Please provide a valid 10-digit Indian contact number starting with 6, 7, 8, or 9.", code: 400 });
        }

        // Check if whatsappNumber is empty or does not meet the pattern (if it's provided)
        if (whatsappNumber && !/^[6-7-8-9]\d{9}$/.test(whatsappNumber)) {
            return res.status(400).json({ msg: "Please provide a valid 10-digit Indian WhatsApp number starting with 6, 7, 8, or 9.", code: 400 });
        }

        // Check if a customer with the same email already exists
        const existingCustomer = await Customer.findOne({ email });
        if (existingCustomer) {
            return res.status(400).json({ msg: "Customer with this email already exists.", code: 400 });
        }

        // Create a new customer instance
        const newCustomer = new Customer({ name, contactNumber, email, whatsappNumber });
        
        // Save the customer to the database
        const savedCustomer = await newCustomer.save();

        // Return success response
        return res.status(201).json({ msg: "New customer data added to DB.", savedCustomer });

    } catch (error) {
        // Handle validation error messages from Mongoose
        if (error.name === 'ValidationError') {
            return res.status(400).json({ msg: "Validation error", details: error.message });
        }

        // Handle other types of errors
        res.status(500).json({ msg: "Error saving customer", error });
    }
};


// Controller to get all customers
const getCustomers = async (req, res) => {
    try {
        const customers = await Customer.find();
        // res.status(200).json(customers);
        res.status(200).json({msg:"All  Customer Datas added in Db...",data:customers})
        console.log(customers);
        
    } catch (error) {
        res.status(500).json({ message: "Error fetching customers", error });
    }
};

module.exports = {
    addCustomer,
    getCustomers
};
