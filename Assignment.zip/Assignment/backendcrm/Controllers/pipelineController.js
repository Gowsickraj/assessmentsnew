const Pipeline = require("../Module/Pipeline");

const addPipelineData = async (req, res) => {
  const { customerName, referredBy, description, status } = req.body;

  try {
    // Validate required fields
    if (!customerName || !referredBy || !description) {
      return res.status(400).json({ 
        msg: "Customer Name, Referred By, and Description are required." 
      });
    }

    // Create a new pipeline entry using the validated schema
    const savedEntry = await Pipeline.create({
      customerName,
      referredBy,
      description,
      status
    });

    console.log(savedEntry);
    return res.status(200).json({
      msg: "New pipeline data added to the database.",
      data: savedEntry
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      return res.status(400).json({ 
        msg: "Validation error",
        details: error.message 
      });
    }

    res.status(500).json({ error: "Failed to add pipeline data" });
  }
};

// Controller to get all pipeline data
const getPipelineData = async (req, res) => {
  try {
    const pipelineData = await Pipeline.find();
    res.status(200).json({
      msg: "All pipeline data retrieved from the database.",
      data: pipelineData
    });
    console.log(pipelineData);
  } catch (error) {
    console.log(error.message);
    return res.status(500).json({ error: "Failed to fetch pipeline data" });
  }
};

// Controller to update the status of a pipeline entry
const updatePipelineData = async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  try {
    const pipelineItem = await Pipeline.findById(id);

    if (!pipelineItem) {
      return res.status(404).json({ message: "Pipeline item not found" });
    }

    pipelineItem.status = status;
    await pipelineItem.save();

    return res.status(200).json({
      data: pipelineItem,
      message: "Status updated successfully"
    });
  } catch (error) {
    return res.status(500).json({ message: "Failed to update status", error });
  }
};

module.exports = { addPipelineData, getPipelineData, updatePipelineData };
