const { Issuer, Strategy, TokenSet } = require("openid-client");
const passport = require("passport");
const TokenModel = require("./models/TokenModel"); // Ensure this import is correct

// Discover the issuer based on the IDP_URL environment variable
Issuer.discover(process.env.IDP_URL)
  .then((oidcIssuer) => {
    console.log("IdP Issuer Discovered");
    const client = new oidcIssuer.Client({
      client_id: process.env.CLIENT_ID,
      client_secret: process.env.CLIENT_SECRET,
      response_types: ["code"],
      redirect_uris: process.env.REDIRECT_URIS.split(","),
    });

    // Configure the passport strategy
    passport.use(
      "oidc",
      new Strategy(
        { client, passReqToCallback: true },
        async (req, tokenSet, userinfo, done) => {
          if (tokenSet && userinfo) {
            const data = {
              auth_token: tokenSet.access_token,
              hash: userinfo.sub,
            };

            try {
              await TokenModel.create({
                hash: userinfo.sub,
                access_token: tokenSet.access_token,
                refresh_token: tokenSet.refresh_token,
                expireTime: tokenSet.expires_at,
                jwt: tokenSet.id_token,
              });
              return done(null, data);
            } catch (error) {
              return done(error);
            }
          } else {
            return done("Authentication error", false);
          }
        }
      )
    );
  })
  .catch((err) => {
    console.error("OIDC Issuer discovery error", err);
  });

// Serialize and deserialize user information
passport.serializeUser((user, done) => {
  console.log("serializeUser user");
  done(null, user);
});

passport.deserializeUser((user, done) => {
  console.log("deserializeUser user");
  done(null, user);
});
