const express = require("express");
const { getPipelineData, addPipelineData, updatePipelineData } = require("../Controllers/pipelineController");
const pipelineroute = express.Router()

// Route to add new pipeline data
pipelineroute.post("/addpipeline", addPipelineData);

// Route to get all pipeline data
pipelineroute.get("/getpipeline", getPipelineData);
pipelineroute.put("/updatepipeline/:id", updatePipelineData);

module.exports=pipelineroute