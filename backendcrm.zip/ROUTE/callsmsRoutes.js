const express = require("express")
const { InitiateCall } = require("../Controllers/callapi");
// const SendSms = require("../Controllers/smsController");
const callSmsRoute = express.Router()

////call API
callSmsRoute.post('/trai/b2b/voice',InitiateCall)
// callSmsRoute.post('/trai/b2b/sms', SendSms);

module.exports=callSmsRoute
