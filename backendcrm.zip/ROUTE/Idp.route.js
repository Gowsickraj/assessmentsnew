const express = require("express");
const passport = require("passport");
const 
Idproutes = express.Router();

Idproutes.get("/", (req, res) => {
  console.log("Enter home Log");
  res.send(`<a href="/api/login">Auth provider</a>`);
});

Idproutes.get(
  "/login",
  passport.authenticate("oidc", {
    scope: ["openid", "refresh_token"],
  })
);

Idproutes.post(
    "/login/verify",
    passport.authenticate("oidc",(req,res)=>{
        return res.status(200).json({token:req.user.auth_token,code:200})
    })
)
module.exports=Idproutes