const mongoose = require("mongoose");

const customerSchema = new mongoose.Schema({
    name: { type: String, required: true },
    contactNumber: { 
        type: String, 
        required: true, 
        match: [/^[6-7-8-9]\d{9}$/, "Please enter a valid 10-digit Indian contact number starting with 6, 7, 8, or 9"] 
    },
    email: { type: String, required: true, unique: true },
    whatsappNumber: { 
        type: String, 
        match: [/^[6-7-8-9]\d{9}$/, "Please enter a valid 10-digit Indian WhatsApp number starting with 6, 7, 8, or 9"] 
    }
});

const Customer = mongoose.model("Customer", customerSchema);
module.exports = Customer;
