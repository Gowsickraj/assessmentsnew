// models/SMS.js
const mongoose = require("mongoose");

const SMSSchema = new mongoose.Schema({
  adminNumber: {
    type: String,
    validate: {
      validator: function (v) {
        return /^[6-7-8-9]\d{9}$/.test(v); // Indian phone number validation
      },
      message: "Invalid admin number format",
    },
  },
  customerNumber: {
    type: String,
    required: true,
    validate: {
      validator: function (v) {
        return /^[6-7-8-9]\d{9}$/.test(v); // Indian phone number validation
      },
      message: "Invalid customer number format",
    },
  },
  content: {
    type: String,
    required: true,
    maxlength: 160,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

const SMS = mongoose.model("SMS", SMSSchema);
module.exports=SMS
