const mongoose = require("mongoose");

const pipelineSchema = new mongoose.Schema({
  customerName: {
    type: String,
    required: true,
    trim: true,
    match: [/^[A-Za-z\s]+$/, "Customer name should contain only letters and spaces"],
    maxlength:[25, "CustomerName should not exceed above 25 characters"]
  },
  referredBy: {
    type: String,
    required: true,
    trim: true,
    match: [/^[A-Za-z\s]+$/, "Referred by should contain only letters and spaces"],
  },
  description: {
    type: String,
    required: true,
    maxlength: [160, "Description should not exceed 160 characters"],
  },
  status: {
    type: String,
    enum: ["Referral", "Lead", "In Discussion", "Customer", "Closed"],
    default: "Referral",
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model("Pipeline", pipelineSchema);
