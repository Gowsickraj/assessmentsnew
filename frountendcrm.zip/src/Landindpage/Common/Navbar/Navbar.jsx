import { Link } from "react-router-dom";
import "./Navbar.css";

export const Navbar = () => {
  return (
    <div className="navbar-container">
      <nav className="navbar">
        <ul>
          <li>
            <Link to={"/login"}>Login / Register</Link>
          </li>
        </ul>
      </nav>  
        <div className="navbar_landingPage"><p>Landing Page</p></div>
    </div>
  );
};

export const LandingPage = () => {
  return (
    <div className="crm-landing-page">
      <header className="hero">
        <div className="hero-content">
          <h1>Welcome to Our CRM Solution</h1>
          <p>Manage your customer relationships efficiently and effortlessly.</p>
          <Link to="/signup" className="cta-button">
            Get Started
          </Link>
        </div>
      </header>
    </div>
  );
};
