import React, { useState, useEffect } from "react";
import "./Customer.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faPhone,
  faComment,
  faPerson,
  faAddressCard,
  faEnvelope,
  faUserPlus,
  faPersonMilitaryPointing,
} from "@fortawesome/free-solid-svg-icons";
import { faWhatsapp } from "@fortawesome/free-brands-svg-icons";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axiosInstance from "../../../Utils/axiosInstance";

const GeneralUsersList = () => {
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    contactNumber: "",
    email: "",
    whatsappNumber: "",
  });
  const [customerList, setCustomerList] = useState([]);
  const [whatsappEnabled, setWhatsappEnabled] = useState(false);
  const [smsContent, setSmsContent] = useState("");
  const [smsErrors, setSmsErrors] = useState({});
  const [fetchError, setFetchError] = useState(null);
  const [showSmsPopup, setShowSmsPopup] = useState(false);
  const [currentCustomer, setCurrentCustomer] = useState(null);

  useEffect(() => {
    const fetchCustomers = async () => {
      setLoading(true);
      setFetchError(null);
      try {
        const response = await axiosInstance.get("/crm/getCustomers"); 
        setCustomerList(response.data.data);
      } catch (error) {
        console.error("Error fetching customers:", error);
        setFetchError("Failed to load customers. Please try again later.");
      } finally {
        setLoading(false);
      }
    };
    fetchCustomers();
  }, [showForm]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };
  const validateIndianNumber = (number) => {
    const regex = /^[6-7-8-9]\d{9}$/;
    return regex.test(number);
  };

  const validateEmail = (email) => {
    const emailRegex = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/;
    return emailRegex.test(email);
  };

  const validateSmsContent = (content) => {
    const regex = /^[a-zA-Z0-9.,!?"' ]{1,160}$/;
    return regex.test(content);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let formErrors = {};

    if (!formData.name) {
      formErrors.name = "Name is required.";
    } else if (/\s/.test(formData.name)) {
      formErrors.name = "Name cannot contain spaces.";
    }

    if (!formData.contactNumber) {
      formErrors.contactNumber = "Contact number is required.";
    } else if (!validateIndianNumber(formData.contactNumber)) {
      formErrors.contactNumber =
        "Contact number must be exactly 10 digits and start with 6-7-8-9.";
    } else if (/\s/.test(formData.contactNumber)) {
      formErrors.contactNumber = "Contact number cannot contain spaces.";
    }

    if (!formData.email) {
      formErrors.email = "Email is required.";
    } else if (!validateEmail(formData.email)) {
      formErrors.email = "Please enter a valid email address.";
    } else if (/\s/.test(formData.email)) {
      formErrors.email = "Email cannot contain spaces.";
    }

    if (whatsappEnabled && !validateIndianNumber(formData.whatsappNumber)) {
      formErrors.whatsappNumber =
        "WhatsApp number must be exactly 10 digits and start with 6-7-8-9.";
    } else if (whatsappEnabled && /\s/.test(formData.whatsappNumber)) {
      formErrors.whatsappNumber = "WhatsApp number cannot contain spaces.";
    }

    if (Object.keys(formErrors).length === 0) {
      try {
        await axiosInstance.post("/crm/addcustomer", formData); 
        toast.success("Customer added successfully", {
          autoClose: 2000,
        });

        setFormData({
          name: "",
          contactNumber: "",
          email: "",
          whatsappNumber: "",
        });
        setWhatsappEnabled(false);
        setShowForm(false);
      } catch (error) {
        console.error("Error saving customer:", error);
        setFetchError(
          error.response?.data?.message ||
            "Failed to save customer. Please try again."
        );
        toast.error("Failed to save customer. Please try again.", {
          autoClose: 3000,
        });
      }
    } else {
      setSmsErrors(formErrors);
    }
  };

  const handleSms = async () => {
    if (!validateSmsContent(smsContent)) {
      setSmsErrors({
        smsContent: "SMS content is invalid or exceeds 160 characters.",
      });
      return;
    }

    try {
      const response = await axiosInstance.post("/crm/savesms", {
        adminNumber: "6870670410", 
        customerNumber: currentCustomer.contactNumber,
        content: smsContent,
      });
      toast.success("SMS sent successfully!", {
        position: toast.POSITION,
        autoClose: 3000,
      });
      setSmsContent("");
      setShowSmsPopup(false);
    } catch (error) {
      console.error("Error sending SMS:", error);
      const errorMessage =
        error.response?.data?.error || "Failed to send SMS. Please try again.";
      toast.error(errorMessage, {
        position: toast.POSITION,
        autoClose: 3000,
      });
    }
  };

  const handleCall = (customer) => {
    alert(`Calling ${customer.name} at ${customer.contactNumber}`);
  };

  const handleSmsButtonClick = (customer) => {
    setCurrentCustomer(customer);
    setSmsContent(""); 
    setShowSmsPopup(true); 
  };

  return (
    <div className="listform">
      <ToastContainer />
      <h2>
      <FontAwesomeIcon style={{color:"green",fontSize:"29px"}} icon={faPersonMilitaryPointing}/> Customer Details</h2>
      <div className="crm_addcustomer_form">
        <button onClick={() => setShowForm(true)}>
          <FontAwesomeIcon icon={faUserPlus} /> Add Customer
        </button>
      </div>
      <br />
      {loading && <p>Loading customers...</p>}
      {fetchError && <p className="error">{fetchError}</p>}
      <table>
        <thead>
          <tr>
            <th>
              <FontAwesomeIcon icon={faPerson} /> Name
            </th>
            <th>
              <FontAwesomeIcon icon={faAddressCard} /> Contact Number
            </th>
            <th>
              <FontAwesomeIcon icon={faEnvelope} /> Email Id
            </th>
            <th>
              <FontAwesomeIcon icon={faWhatsapp} /> WhatsApp No
            </th>
            <th>
              <FontAwesomeIcon icon={faPhone} /> Call to Customers
            </th>
            <th>
              <FontAwesomeIcon icon={faComment} /> SMS
            </th>
          </tr>
        </thead>
        <tbody>
          {customerList.length > 0 ? (
            customerList.map((customer) => (
              <tr key={customer._id}>
                <td>{customer.name}</td>
                <td>{customer.contactNumber}</td>
                <td>{customer.email}</td>
                <td>{customer.whatsappNumber || "N/A"}</td>
                <td>
                  <button
                    className="call_button"
                    onClick={() => handleCall(customer)}
                  >
                    <FontAwesomeIcon icon={faPhone} /> Call
                  </button>
                </td>
                <td>
                  <button
                    className="call_button"
                    onClick={() => handleSmsButtonClick(customer)}
                  >
                    <FontAwesomeIcon icon={faComment} /> SMS
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td style={{ fontSize: "17px", fontWeight: "400" }} colSpan="6">
                No data available
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {showForm && (
        <div className="popup">
          <div className="popup-content">
            <h3>Add New Customer</h3>
            <form onSubmit={handleSubmit} autoComplete="off">
              <div>
                <label htmlFor="name">Name:</label>
                <input
                  type="text"
                  name="name"
                  maxLength={25}
                  pattern="^[A-Za-z\s]+$" 
                  id="name"
                  title="Only letters can accepted"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                />
                {smsErrors.name && <p className="error">{smsErrors.name}</p>}
              </div>
              <div>
                <label htmlFor="contactNumber">Contact Number:</label>
                <input
                  type="text"
                  name="contactNumber"
                  id="contactNumber"
                  maxLength={10}
                  value={formData.contactNumber}
                  onChange={handleInputChange}
                  required
                />
                {smsErrors.contactNumber && (
                  <p className="error">{smsErrors.contactNumber}</p>
                )}
              </div>
              <div>
                <label htmlFor="email">Email:</label>
                <input
                  type="email"
                  name="email"
                  maxLength={30}
                  id="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                />
                {smsErrors.email && <p className="error">{smsErrors.email}</p>}
              </div>
              <div>
                <label>
                  <input
                    type="checkbox"
                    checked={whatsappEnabled}
                    onChange={() => setWhatsappEnabled(!whatsappEnabled)}
                  />
                  Enable WhatsApp Number
                </label>
              </div>
              {whatsappEnabled && (
                <div>
                  <label htmlFor="whatsappNumber">WhatsApp No:</label>
                  <input
                    type="text"
                    name="whatsappNumber"
                    maxLength={10}
                    id="whatsappNumber"
                    value={formData.whatsappNumber}
                    onChange={handleInputChange}
                  />
                  {smsErrors.whatsappNumber && (
                    <p className="error">{smsErrors.whatsappNumber}</p>
                  )}
                </div>
              )}
              <button type="submit">Submit</button>
              <button type="button" onClick={() => setShowForm(false)}>
                Cancel
              </button>
            </form>
          </div>
        </div>
      )}

      {showSmsPopup && (
        <div className="popup">
          <div className="popup-content">
            <h3>Send SMS to {currentCustomer?.name}</h3>
            <textarea
              value={smsContent}
              onChange={(e) => setSmsContent(e.target.value)}
              maxLength={160}
              placeholder="Enter your SMS content here"
              rows="4"
              cols="50"
            />
            {smsErrors.smsContent && (
              <p className="error">{smsErrors.smsContent}</p>
            )}
            <button onClick={handleSms}>Send</button>
            <button
              className="sms_close"
              onClick={() => setShowSmsPopup(false)}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default GeneralUsersList;
