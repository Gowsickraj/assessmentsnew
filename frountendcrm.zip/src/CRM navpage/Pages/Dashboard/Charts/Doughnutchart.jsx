import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import '../Dashboard.css'

ChartJS.register(ArcElement, Tooltip, Legend);

export const DoughnutChart = () => {
    const data = {
        labels: ['Voice Log', 'SMS Log'],
        datasets: [
            {
                label: 'Content Logs',
                data: [300, 200], 
                backgroundColor: ['#FF6384', '#36A2EB'],
                hoverBackgroundColor: ['#FF6384', '#36A2EB']
            }
        ]
    };

    const options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top'
            },
            tooltip: {
                enabled: true
            }
        }
    };

    return (
        <div style={{ width: '450px', height: '300px',marginTop:"10px" }}>
            <Doughnut data={data} options={options} />
        </div>
    );
};
