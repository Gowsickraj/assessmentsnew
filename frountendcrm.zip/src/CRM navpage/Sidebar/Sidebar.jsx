import { Link } from "react-router-dom";
import "./Sidebar.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faGaugeHigh,
  faPersonMilitaryPointing,
  faBarsStaggered,
  faRightFromBracket,
} from "@fortawesome/free-solid-svg-icons";

export const Sidebar = () => {
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("hash");
    window.location.href = "/";
  };
  return (
    <div>
      <div className="sidebar">
        <div className="crm-user-title">
          <h2>CRM</h2>
        </div>
        <nav>
          <ul>
            <li>
              <Link to="/crm/user-dashboard">
                <FontAwesomeIcon
                  style={{ color: "yellow", fontSize: "20px" }}
                  icon={faGaugeHigh}
                />{" "}
                Dashboard
              </Link>
            </li>
            <li>
              <Link to="/crm/user-customer">
                <FontAwesomeIcon
                  style={{ color: "yellow", fontSize: "20px" }}
                  icon={faPersonMilitaryPointing}
                />{" "}
                Customer
              </Link>
            </li>
            <li>
              <Link to="/crm/user-pipeline">
                <FontAwesomeIcon
                  style={{ color: "yellow", fontSize: "20px" }}
                  icon={faBarsStaggered}
                />{" "}
                Pipeline
              </Link>
            </li>
            {/* <li>
              <Link to="/crm/user-channel">Channel</Link>
            </li> */}
          </ul>
        </nav>
        <div className="crm_logout">
          <Link to="/" onClick={handleLogout} className="crm-logout">
            <FontAwesomeIcon
              style={{ color: "red", fontSize: "20px" }}
              icon={faRightFromBracket}
            />{" "}
            Logout
          </Link>
        </div>
      </div>
    </div>
  );
};
