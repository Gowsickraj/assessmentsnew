import { createBrowserRouter, RouterProvider } from 'react-router-dom';
// import { Navbar } from '../Landindpage/Common/Navbar/Navbar';
import { Layout } from '../CRM navpage/Layout/CrmuserLayout';
import NotFound from '../NotFount/Errorpage';
// import UserForm from '../Landindpage/Common/LoginForm/Loginform';
import Customer from '../CRM navpage/Pages/Customer/Customer';
import Channel from '../CRM navpage/Pages/Channel/Channel';
import Pipeline from '../CRM navpage/Pages/Pipeline/Pipeline';
import { Dashboard } from '../CRM navpage/Pages/Dashboard/Dashboard';

function App() {
  const router = createBrowserRouter([
    // {
    //   path: "/",
    //   element: <Navbar />,
    // },
    {
      path: "/crm",
      element: <Layout />,
      children:[{path:"user-dashboard",element:<Dashboard/>},
        {path:"user-customer",element:<Customer/>},
        {path:"user-pipeline",element:<Pipeline/>},
        {path:"user-channel",element:<Channel/>}
      ]
    },
    // {
    //   path: "/login",
    //   element: <UserForm/>
    // },
    {
      path: "*",
      element: <NotFound />,
    }
  ]);

  return (
    <div>
      <RouterProvider router={router} />
    </div>
  );
}

export default App;
