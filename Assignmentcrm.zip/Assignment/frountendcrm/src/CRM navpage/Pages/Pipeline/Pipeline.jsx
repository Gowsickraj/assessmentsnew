import React, { useState, useEffect } from "react";
import "./Pipeline.css";
import axiosInstance from "../../../Utils/axiosInstance";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBarsStaggered, faUserPlus } from "@fortawesome/free-solid-svg-icons";

const Pipeline = () => {
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [formData, setFormData] = useState({
    customerName: "",
    referredBy: "",
    description: "",
    status: "Referral",
  });
  const [pipelineData, setPipelineData] = useState([]);
  const [errors, setErrors] = useState({
    customerName: "",
    referredBy: "",
    description: "",
  });

  const openPopup = () => setIsPopupOpen(true);
  const closePopup = () => setIsPopupOpen(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });

    if (name === "customerName") {
      if (!/^[A-Za-z\s]*$/.test(value)) {
        setErrors((prevErrors) => ({
          ...prevErrors,
          customerName: "Only letters and spaces allowed.",
        }));
      } else {
        setErrors((prevErrors) => ({ ...prevErrors, customerName: "" }));
      }
    }

    if (name === "referredBy") {
      if (!/^[A-Za-z\s]*$/.test(value)) {
        setErrors((prevErrors) => ({
          ...prevErrors,
          referredBy: "Only letters and spaces allowed.",
        }));
      } else {
        setErrors((prevErrors) => ({ ...prevErrors, referredBy: "" }));
      }
    }

    if (name === "description") {
      if (value.length > 160) {
        setErrors((prevErrors) => ({
          ...prevErrors,
          description: "Description cannot exceed 160 characters.",
        }));
      } else {
        setErrors((prevErrors) => ({ ...prevErrors, description: "" }));
      }
    }
  };

  useEffect(() => {
    const fetchPipelineData = async () => {
      try {
        const response = await axiosInstance.get("/pipelines/getpipeline");
        setPipelineData(response.data.data);
      } catch (error) {
        console.error("Failed to fetch pipeline data:", error);
      }
    };
    fetchPipelineData();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (errors.customerName || errors.referredBy || errors.description) {
      return; 
    }
    try {
      const response = await axiosInstance.post(
        "/pipelines/addpipeline",
        formData
      );
      setPipelineData([...pipelineData, response.data.data]);
      setFormData({
        customerName: "",
        referredBy: "",
        description: "",
        status: "Referral",
      });
      closePopup();
    } catch (error) {
      console.error("Failed to add pipeline data:", error);
    }
  };
  const onDragEnd = async (result) => {
    const { source, destination, draggableId } = result;
    if (!destination) return;

    const item = pipelineData.find((data) => data._id === draggableId);
    if (!item || source.droppableId === destination.droppableId) return;

    const updatedData = pipelineData.map((data) =>
      data._id === draggableId
        ? { ...data, status: destination.droppableId }
        : data
    );
    setPipelineData(updatedData);

    try {
      await axiosInstance.put(`/pipelines/updatepipeline/${draggableId}`, {
        status: destination.droppableId,
      });
      console.log("Status updated successfully");
    } catch (error) {
      console.error("Failed to update pipeline data:", error);
    }
  };

  const groupedData = pipelineData.reduce((acc, item) => {
    const status = item.status || "Referral";
    if (!acc[status]) acc[status] = [];
    acc[status].push(item);
    return acc;
  }, {});

  const statuses = ["Referral", "Lead", "In Discussion", "Customer", "Closed"];

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div className="pipeline-crm">
        <h2>
          <FontAwesomeIcon
            style={{ color: "green", fontSize: "25px" }}
            icon={faBarsStaggered}
          />{" "}
          Pipeline Details
        </h2>
        <div className="crm_pipeline_form">
          <button onClick={openPopup}>
            <FontAwesomeIcon icon={faUserPlus} /> Add
          </button>
        </div>
        <br />
        <table>
          <thead>
            <tr>
              {statuses.map((status) => (
                <th key={status}>{status}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            <tr>
              {statuses.map((status) => (
                <Droppable droppableId={status} key={status}>
                  {(provided) => (
                    <td
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      className="status-column"
                    >
                      {groupedData[status]?.length > 0 ? (
                        groupedData[status].map((item, index) => (
                          <Draggable
                            key={item._id}
                            draggableId={item._id}
                            index={index}
                          >
                            {(provided) => (
                              <div
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                {...provided.dragHandleProps}
                                className="card_pipeline"
                              >
                                <span>
                                  <b>Name: </b>
                                  {item.customerName}
                                </span>
                                <br />
                                <span>
                                  <b>Referred By: </b>
                                  {item.referredBy}
                                </span>
                                <br />
                                <span>
                                  <b title={item.description}>Description</b>
                                </span>
                                <br />
                                <span>
                                  <b>Status: </b>
                                  {item.status}
                                </span>
                              </div>
                            )}
                          </Draggable>
                        ))
                      ) : (
                        <div className="no-data-message">No data available</div>
                      )}
                      {provided.placeholder}
                    </td>
                  )}
                </Droppable>
              ))}
            </tr>
          </tbody>
        </table>
        {isPopupOpen && (
          <div className="popup">
            <div className="popup-content">
              <h3>Add Pipeline Details</h3>
              <form onSubmit={handleSubmit} autoComplete="off">
                <label>
                  Customer Name:
                  <input
                    type="text"
                    name="customerName"
                    maxLength={25}
                    value={formData.customerName}
                    onChange={handleInputChange}
                    required
                  />
                  {errors.customerName && (
                    <span style={{ color: "red", fontSize: "12px" }}>
                      {errors.customerName}
                    </span>
                  )}
                </label>
                <label>
                  Referred By:
                  <input
                    type="text"
                    name="referredBy"
                    maxLength={25}
                    value={formData.referredBy}
                    onChange={handleInputChange}
                    required
                  />
                  {errors.referredBy && (
                    <span style={{ color: "red", fontSize: "12px" }}>
                      {errors.referredBy}
                    </span>
                  )}
                </label>
                <label>
                  Description:
                  <textarea
                    name="description"
                    maxLength={160}
                    value={formData.description}
                    onChange={handleInputChange}
                    required
                    rows={4}
                  />
                  {errors.description && (
                    <span style={{ color: "red", fontSize: "12px" }}>
                      {errors.description}
                    </span>
                  )}
                </label>
                <label>
                  Status:
                  <select
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                    required
                  >
                    {statuses.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </label>
                <button type="submit">Submit</button>
                <button type="button" onClick={closePopup}>
                  Close
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </DragDropContext>
  );
};

export default Pipeline;
