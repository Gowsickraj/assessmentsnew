import React, { useState, useEffect, useRef } from "react";
import axiosInstance from "../../../Utils/axiosInstance";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPhone, faComment } from "@fortawesome/free-solid-svg-icons";
import "./Channel.css"; 

const Channel = () => {
  const [customerList, setCustomerList] = useState([]);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const formRef = useRef(null);

  const initialFormData = {
    platform: "web",
    name: "",
    mobilenumber: "",
    email: "",
    amount: "",
    creditcardnumber: "",
  };

  const [formData, setFormData] = useState(initialFormData);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const response = await axiosInstance.get("routeAPI");
        setCustomerList(response.data);
      } catch (error) {
        console.error("Error fetching customers:", error);
      }
    };
    fetchCustomers();
  }, []);

  const handleAddFundsClick = () => {
    setShowPaymentForm(true);
  };

  const handleClosePopup = () => {
    setShowPaymentForm(false);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
    setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.name) newErrors.name = "Name is required";
    if (!formData.email) newErrors.email = "Email is required";
    else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = "Invalid email format";
    if (!formData.mobilenumber) newErrors.mobilenumber = "Mobile number is required";
    else if (!/^\d{10}$/.test(formData.mobilenumber)) newErrors.mobilenumber = "Must be 10 digits";
    if (!formData.creditcardnumber) newErrors.creditcardnumber = "Credit card number is required";
    else if (!/^\d{4}$/.test(formData.creditcardnumber)) newErrors.creditcardnumber = "Must be 4 digits";
    if (!formData.amount) newErrors.amount = "Amount is required";
    else if (isNaN(formData.amount) || Number(formData.amount) <= 0) newErrors.amount = "Positive number required";

    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) return;

    try {
      const res = await axiosInstance.post("/transaction/trans", formData, { timeout: 30000 });
      if (res.data.code === 200) {
        let form = res.data.value;
        if (formRef.current) {
          formRef.current.innerHTML = form;
          const formElement = formRef.current.querySelector("form");
          if (formElement) {
            HTMLFormElement.prototype.submit.call(formElement);
          }
        }
      }
    } catch (error) {
      console.error("Payment Error:", error);
    }
  };

  return (
    <div className="listform">
      <h2>Channel Details</h2>
      <div className="crm_addcustomer_form">
        <div className="crm_call_sms">
          <div className="crm_customer_call">
            <button>
              <FontAwesomeIcon icon={faPhone} /> Call
            </button>
          </div>
          <div className="crm_customer_sms">
            <button>
              <FontAwesomeIcon icon={faComment} /> SMS
            </button>
          </div>
        </div>
        <div>
          <button>Balance</button>
          <button onClick={handleAddFundsClick}>Add Funds</button>
        </div>
      </div>
      <br />
      <table>
        <thead>
          <tr>
            <th>Agency Name</th>
            <th>Customer</th>
            <th>In-telephone Number</th>
            <th>Recovery</th>
            <th>Status</th>
            <th>Timing</th>
          </tr>
        </thead>
        <tbody>
          {customerList.length > 0 ? (
            customerList.map((customer) => (
              <tr key={customer.id || customer.contactNumber}>
                <td>{customer.agencyName || "N/A"}</td>
                <td>{customer.name || "N/A"}</td>
                <td>{customer.inTelephoneNumber || "N/A"}</td>
                <td>{customer.recovery || "N/A"}</td>
                <td>{customer.status || "N/A"}</td>
                <td>{customer.timing || "N/A"}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td style={{ fontSize: "17px", fontWeight: "400" }} colSpan="6">
                No customers found
              </td>
            </tr>
          )}
        </tbody>
      </table>
      
      {showPaymentForm && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={handleClosePopup}>&times;</span>
            <form className="payments_donate_forms" onSubmit={handleSubmit}>
              <h2>Payment Form</h2>
              <div className="width_for_paymentsform">
                <div>
                  <label className="payment_name">
                    Name <br />
                    <input type="text" placeholder="Enter your name" name="name" value={formData.name} onChange={handleChange} />
                    <br />
                    {errors.name && <span className="error">{errors.name}</span>}
                  </label>
                </div>
                <div>
                  <label className="payment_email">
                    Email <br />
                    <input type="email" name="email" placeholder="Enter email" value={formData.email} onChange={handleChange} />
                    <br />
                    {errors.email && <span className="error">{errors.email}</span>}
                  </label>
                </div>
                <div>
                  <label className="payment_number">
                    Mobile Number <br />
                    <input type="text" name="mobilenumber" placeholder="Mobile number" value={formData.mobilenumber} onChange={handleChange} />
                    <br />
                    {errors.mobilenumber && <span className="error">{errors.mobilenumber}</span>}
                  </label>
                </div>
                <div>
                  <label className="payment_card_number">
                    Credit Card Number <br />
                    <input type="text" name="creditcardnumber" placeholder="Last 4 digits" value={formData.creditcardnumber} onChange={handleChange} />
                    <br />
                    {errors.creditcardnumber && <span className="error">{errors.creditcardnumber}</span>}
                  </label>
                </div>
                <div>
                  <label className="payment_amount">
                    Amount :<br />
                    <input type="text" name="amount" placeholder="Enter amount" value={formData.amount} onChange={handleChange} />
                    <br />
                    {errors.amount && <span className="error">{errors.amount}</span>}
                  </label>
                </div>
                <button className="donate_button" type="submit">Pay Now</button>
              </div>
            </form>
            <div ref={formRef}></div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Channel;
