const express = require("express");
require("dotenv").config();
const session = require("express-session")
const cors = require("cors");
const helmet = require ("helmet");
const passport = require("passport");
const connectDB = require("./Database/Db");
const router = require("./ROUTE/customerRoutes");
const Idproutes = require("./ROUTE/Idp.route");
const pipelineroute = require("./ROUTE/pipelineRoutes");
const callSmsRoute = require("./ROUTE/callsmsRoutes");
const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Connect to MongoDB
connectDB();
// API routes
app.use("/api/crm", router) // Use customer routes
app.use("/api/pipelines", pipelineroute);// Use pipeline routes
app.use("/api",callSmsRoute)//Call&sms API's Route

app.use(
    cors({
        origin:"http://localhost:3000",
        credentials:true,
        allowedHeaders:["Content-Type","Authorization"],
    })
)
app.use(helmet());
app.use(
    session({
        secret:"hbcuachuasih",
        resave:true,
        saveUninitialized:true,
        cookie:{secure:true},
        
    })
)

app.use(passport.initialize())
app.use(passport.session())

app.use('/api',Idproutes);
const PORT = process.env.PORT || 4000;
const server=app.listen(PORT, () => {
    console.log(`Server is connected on http://localhost:${PORT}`);
});
server.on("request",(req,res)=>{
    console.log(req.method,">>>>>>>>>>>>",req.originalUrl);
})
