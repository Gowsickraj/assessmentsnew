const express = require("express");
const { addCustomer, getCustomers } = require("../Controllers/customerController");
const Savesms = require("../Controllers/smsController");
const router = express.Router();

// Route to add a customer
router.post("/addcustomer", addCustomer);

// Route to get all customers
router.get("/getCustomers", getCustomers);

///CousterSMS Api
router.post("/savesms",Savesms)



module.exports = router;
